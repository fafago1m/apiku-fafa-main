
global.creator = "Skyzopedia"
global.apikey = ["apikey1", "apikey2", "apikey3"]