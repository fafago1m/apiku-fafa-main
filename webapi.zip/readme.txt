oiginal scraper by zakkiXD-Dev 
082137435046